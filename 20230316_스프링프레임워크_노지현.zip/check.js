
function nextPage() {
    if(document.getElementById("Check_1_").checked && document.getElementById("Check_2_").checked) {
        location.assign("main.html");
    }else{
        alert("필수 항목 동의가 필요합니다.")  
    }
}


function change(){

    if(document.getElementById("mainCheck_").checked == true){
        document.getElementById("mainCheck_").checked = true;
        document.getElementById("Check_1_").checked = true;
        document.getElementById("Check_2_").checked = true;
        document.getElementById("Check_3_").checked = true;
        document.getElementById("Check_4_").checked = true;


    }else{
        document.getElementById("mainCheck_").checked = false;
        document.getElementById("Check_1_").checked = false;
        document.getElementById("Check_2_").checked = false;
        document.getElementById("Check_3_").checked = false;
        document.getElementById("Check_4_").checked = false;
    }
    
}


function change_target(){
    let count = 0;
    for(i = 1; i <= 4; i ++){
        if(document.getElementById("Check_" + i + "_").checked == true){
            count ++;
            if(count == 4){
                document.getElementById("mainCheck_").checked = true;
            }else{
                document.getElementById("mainCheck_").checked = false;
            }
        }else{
            count --;
        }
    }
    
}



