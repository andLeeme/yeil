function nextPage() {
  
      location.assign("complete.html");
}



window.onload = function () {
  const idValueBox = document.querySelector("[name = idBox] > input");       //아이디 인풋박스 클릭했을때 보더컬러 변경
  idValueBox.addEventListener("focus", () => {
    document.querySelector("[name = idBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  idValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = idBox]").style.border = "1px solid #dad8d8"; 
    const idCheck  = /^(?=.*\d)(?=.*[a-z])[0-9a-z]{4,19}$/;                    //아이디검증 정규식
    if (idValueBox.value == "") {
      const idWarningBox = document.querySelector("[name=idWarningBox]"); //  포커스아웃시 아이디가 공란일때
      idWarningBox.style.display = "block";
      idWarningBox.textContent = "필수 정보 입니다";

    }else if(idCheck.test(idValueBox.value)==false && idValueBox.value != ""){   //아이디 형식에 맞지않을때
      const idWarningBox = document.querySelector("[name=idWarningBox]");
      idWarningBox.style.display = "block";
      idWarningBox.textContent = "5~20자의 영문 소문자, 숫자만 사용 가능합니다.";

    }else if(idCheck.test(idValueBox.value)==true){                              
      const idWarningBox = document.querySelector("[name=idWarningBox]");     //아이디 형식에 맞을때
      idWarningBox.style.display = "block"; 
      idWarningBox.style.color = "green";
      idWarningBox.textContent = "멋진 아이디네요!";
  
    }
  });
  const pwValueBox = document.querySelector("[name = pwBox] > input");      //비번 포커스시 테두리 색 변경
  pwValueBox.addEventListener("focus", () => {
    document.querySelector("[name = pwBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });

  pwValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = pwBox]").style.border = "1px solid #dad8d8";  //포커스아웃시  보더 컬러 리셋

    const dangerPwCheck = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,16}$/;                       //비번검증 보통 정규식

    const safePwCheck = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,16}$/;   //비번검증 안전 정규식

    if (pwValueBox.value == "") {
      const pwWarningBox = document.querySelector("[name=pwWarningBox]");          //입력한 비번값이 없을때
      pwWarningBox.style.display = "block";
      pwWarningBox.textContent = "필수 정보 입니다";

    }else if(dangerPwCheck.test(pwValueBox.value)==false && pwValueBox.value != ""){   // 보통 정규식에도 맞지않을 때
      const pwWarningBox = document.querySelector("[name=pwWarningBox]");
      pwWarningBox.style.display = "block";
      pwWarningBox.textContent = "8~16자 영문 대 소문자, 숫자, 특수문자를 사용하세요.";

    }else if(dangerPwCheck.test(pwValueBox.value)==true &&  safePwCheck.test(pwValueBox.value)==false){
      const pwWarningBox = document.querySelector("[name=pwWarningBox]");                //보통 정규식에 맞고 안전 정규식에 맞지 않을때
      pwWarningBox.style.display = "block";
      pwWarningBox.textContent = "8~16자 영문 대 소문자, 숫자, 특수문자를 사용하세요.";

    }if(safePwCheck.test(pwValueBox.value)==true){ 
      const pwWarningBox = document.querySelector("[name=pwWarningBox]");              //safety pw
      pwWarningBox.style.display = "none";
  
      
    }
  }
  );

  const pwChkValueBox = document.querySelector("[name = pwChkBox] > input");
  pwChkValueBox.addEventListener("focus", () => {
    document.querySelector("[name = pwChkBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  pwChkValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = pwChkBox]").style.border =
      "1px solid #dad8d8";

    if (pwChkValueBox.value === "") {
      const pwChkWarningBox = document.querySelector("[name=pwChkWarningBox]"); //비번확인검증
      pwChkWarningBox.style.display = "block";
      pwChkWarningBox.textContent = "필수 정보 입니다";
    }else if(pwChkValueBox.value == pwValueBox.value){
      const pwChkWarningBox = document.querySelector("[name=pwChkWarningBox]"); 
      pwChkWarningBox.style.display = "none";
    }
    else if(pwChkValueBox.value != pwValueBox.value){
      const pwChkWarningBox = document.querySelector("[name=pwChkWarningBox]"); 
      pwChkWarningBox.style.display = "block";
      pwChkWarningBox.textContent = "비밀번호가 일치하지 않습니다.";
    }
  });



  const nameCheck =  /^[가-힣]{2,4}|[a-zA-Z]{2,10}\s[a-zA-Z]{2,10}$/;

  const nameValueBox = document.querySelector("[name = nameBox] > input");
  nameValueBox.addEventListener("focus", () => {
    document.querySelector("[name = nameBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  nameValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = nameBox]").style.border =
      "1px solid #dad8d8";

    if (nameValueBox.value == "") {
      const nameWarningBox = document.querySelector("[name=nameWarningBox]"); //이름검증
      nameWarningBox.style.display = "block";
      nameWarningBox.textContent = "필수 정보 입니다";
    }else if(nameCheck.test(nameValueBox.value)==false){
      const nameWarningBox = document.querySelector("[name=nameWarningBox]");
      nameWarningBox.style.display = "block";
      nameWarningBox.textContent = "한글과 영문 대 소문자를 사용하세요. (특수기호, 공백 사용 불가)";
    }if(nameCheck.test(nameValueBox.value)==true){
      const nameWarningBox = document.querySelector("[name=nameWarningBox]");
      nameWarningBox.style.display = "none";
      


      
    }
  });




  const emailValueBox = document.querySelector("[name = emailBox] > input");  //이메일 검증
  emailValueBox.addEventListener("focus", () => {
    document.querySelector("[name = emailBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  emailValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = emailBox]").style.border =
      "1px solid #dad8d8";
  });

  const safeValueBox = document.querySelector("[name = safeBox] > input");  
  safeValueBox.addEventListener("focus", () => {
    document.querySelector("[name = safeBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  safeValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = safeBox]").style.border =
      "1px solid #dad8d8";
  });




  const yearValueBox = document.querySelector("[name = yearBox]");  //생년월일 검증
  yearValueBox.addEventListener("focus", () => {
    yearValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  yearValueBox.addEventListener("focusout", () => {

    yearCheck =  "/\\d{4}/"

    yearValueBox.style.border = "1px solid #dad8d8";
    if (dayValueBox.value == "") {
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      dayWarningBox.style.display = "block";
      dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
    }
    // else if ( ) {
    //   const dayWarningBox = document.querySelector("[name=dayWarningBox]");
    //   dayWarningBox.style.display = "block";
    //   dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
    // }
  }); 




  const dayValueBox = document.querySelector("[name = dayBox]");
  dayValueBox.addEventListener("focus", () => {
    dayValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  dayValueBox.addEventListener("focusout", () => {
    dayValueBox.style.border = "1px solid #dad8d8";
  });

  const genderValueBox = document.querySelector("[name = genderBox]");
  genderValueBox.addEventListener("focus", () => {
    genderValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  genderValueBox.addEventListener("focusout", () => {
    genderValueBox.style.border = "1px solid #dad8d8";
  });

  const mouthValueBox = document.querySelector("[name = mouthBox]");
  mouthValueBox.addEventListener("focus", () => {
    mouthValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  mouthValueBox.addEventListener("focusout", () => {
    mouthValueBox.style.border = "1px solid #dad8d8";
  });





  const phoneValueBox = document.querySelector("[name = phoneBox]");  //휴대폰 검증
  phoneValueBox.addEventListener("focus", () => {
    phoneValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  phoneValueBox.addEventListener("focusout", () => {

    phoneCheck = /^\d{3}-?\d{3,4}-?\d{4}$/;

    phoneValueBox.style.border = "1px solid #dad8d8";
    if (phoneValueBox.value == "") {
      const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
      phoneWarningBox.style.display = "block";
      phoneWarningBox.textContent = "필수 정보 입니다";

    }else if (phoneCheck.test(phoneValueBox.value)==false) {
      const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
      phoneWarningBox.style.display = "block";
      phoneWarningBox.textContent = "형식에 맞지 않는 번호입니다.";

    } else if (phoneCheck.test(phoneValueBox.value)==true) {
      const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
      phoneWarningBox.style.display = "block";
      phoneWarningBox.style.color="green"
      phoneWarningBox.innerHTML = '인증번호를 발송했습니다.(유효시간 30분)\<br>\
      인증번호가 오지 않으면 입력하신 정보가 정확한지 확인하여 주세요.\<br>\
      이미 가입된 번호이거나, 가상전화번호는 인증번호를 받을 수 없습니다.';
      selectButton();
    }


  });

  function selectButton() {
  const button = document.querySelector(".phoneSummitButton");
  button.onclick (()=>{
    document.querySelector("#phoneCertBox").onclick = document.querySelector("[name=phoneWarningBox]");
    
  });


  }

  const countryValueBox = document.querySelector("[name = countryBox]");
  countryValueBox.addEventListener("focus", () => {
    countryValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });

  countryValueBox.addEventListener("focusout", () => {
    countryValueBox.style.border = "1px solid #dad8d8";
  });

  
};

function nextPage() {

  location.assign("complete.html");
}


