let idTrue = "false";
let pwTrue = "false";
let pwChkTrue = "false";
let nameTrue = "false";
let True = "false";
let yearTrue = "false";
let mouthTrue = "false";
let dayTrue = "false";
let genderTrue = "false";
let phoneTrue = "false";

window.onload = function () {
  const idValueBox = document.querySelector("[name = idBox] > input"); //인풋박스 클릭했을때 보더컬러 변경
  idValueBox.addEventListener("focus", () => {
    document.querySelector("[name = idBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });

  idValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = idBox]").style.border = "1px solid #dad8d8";

    const idCheck = /^(?=.*\d)(?=.*[a-z])[0-9a-z]{5,20}$/;

    if (idValueBox.value == "") {
      const idWarningBox = document.querySelector("[name=idWarningBox]"); //  아이디 정규식 검증
      idWarningBox.style.display = "block";
      idWarningBox.style.color = "red";
      idWarningBox.textContent = "필수 정보 입니다";

      idTrue = "false";
    } else if (
      idCheck.test(idValueBox.value) == false &&
      idValueBox.value != ""
    ) {
      const idWarningBox = document.querySelector("[name=idWarningBox]");
      idWarningBox.style.display = "block";
      idWarningBox.style.color = "red";
      idWarningBox.textContent =
        "5~20자의 영문 소문자, 숫자만 사용 가능합니다.";

      idTrue = "false";
    } else if (idCheck.test(idValueBox.value) == true) {
      const idWarningBox = document.querySelector("[name=idWarningBox]");
      idWarningBox.style.display = "block";
      idWarningBox.style.color = "green";
      idWarningBox.textContent = "멋진 아이디네요!";

      idTrue = "true";

      console.log(idTrue);
    }
  });

  const pwValueBox = document.querySelector("[name = pwBox] > input");
  pwValueBox.addEventListener("focus", () => {
    document.querySelector("[name = pwBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });

  pwValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = pwBox]").style.border = "1px solid #dad8d8";

    const dangerPwCheck = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,16}$/; //비번검증 보통 정규식

    const safePwCheck =
      /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,16}$/; //비번검증 안전 정규식

    if (pwValueBox.value == "") {
      const pwWarningBox = document.querySelector("[name=pwWarningBox]"); //입력한 값이 없을 때
      pwWarningBox.style.display = "block";
      pwWarningBox.textContent = "필수 정보 입니다";

      pwTrue = "false";

      document.querySelector("[name = pwImg]").src = "img/warning.png"; //이미지 변경
      document.querySelector(".pwText").style.display = "block";
      document.querySelector(".pwText").style.color = "red";
      document.querySelector(".pwText").style.marginLeft = "373px";
      document.querySelector(".pwText").textContent = "사용불가";


    } else if (
      dangerPwCheck.test(pwValueBox.value) == false &&
      pwValueBox.value != ""
    ) {
      const pwWarningBox = document.querySelector("[name=pwWarningBox]");
      pwWarningBox.style.display = "block";
      pwWarningBox.textContent =

        "8~16자 영문 대 소문자, 숫자, 특수문자를 사용하세요."; // 보통 정규식에도 맞지않을 때

      document.querySelector("[name = pwImg]").src = "img/warning.png";

      document.querySelector(".pwText").style.display = "block";
      document.querySelector(".pwText").style.color = "red";
      document.querySelector(".pwText").style.marginLeft = "373px";
      document.querySelector(".pwText").textContent = "사용불가";

      pwTrue = "false";
    } else if (
      dangerPwCheck.test(pwValueBox.value) == true &&
      safePwCheck.test(pwValueBox.value) == false
    ) {
      const pwWarningBox = document.querySelector("[name=pwWarningBox]"); //보통 정규식에 맞고 안전 정규식에 맞지 않을때
      pwWarningBox.style.display = "block";
      pwWarningBox.textContent = "8~16자 영문 대 소문자, 숫자, 특수문자를 사용하세요.";

      pwTrue = "true";

      console.log(pwTrue);

      document.querySelector("[name = pwImg]").src = "img/normal.png";
      document.querySelector(".pwText").style.display = "block";

      document.querySelector(".pwText").style.color = "rgb(238, 135, 67)";
      document.querySelector(".pwText").style.marginLeft = "395px";
      document.querySelector(".pwText").textContent = "보통";


      console.log(pwTrue);
    }
    if (safePwCheck.test(pwValueBox.value) == true) {
      const pwWarningBox = document.querySelector("[name=pwWarningBox]"); //safety pw
      pwWarningBox.style.display = "none";

      pwTrue = "true";

      document.querySelector("[name = pwImg]").src = "img/safe.png";

      console.log(pwTrue);

      document.querySelector("[name = pwImg]").src = "img/safe.png";
      document.querySelector(".pwText").style.display = "block";

      document.querySelector(".pwText").style.color = "rgb(47, 184, 47)";
      document.querySelector(".pwText").style.marginLeft = "395px";
      document.querySelector(".pwText").textContent = "안전";
    }
  });



  const pwChkValueBox = document.querySelector("[name = pwChkBox] > input");
  pwChkValueBox.addEventListener("focus", () => {
    document.querySelector("[name = pwChkBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  pwChkValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = pwChkBox]").style.border =
      "1px solid #dad8d8";

    if (pwChkValueBox.value === "") {
      const pwChkWarningBox = document.querySelector("[name=pwChkWarningBox]"); //비번과 확인 검증
      pwChkWarningBox.style.display = "block";
      pwChkWarningBox.textContent = "필수 정보 입니다";

      pwChkTrue = "false";

      document.querySelector("[name = pwChkImg]").src = "img/warning.png";
    } else if (pwChkValueBox.value == pwValueBox.value) {
      const pwChkWarningBox = document.querySelector("[name=pwChkWarningBox]");
      pwChkWarningBox.style.display = "none";
      pwChkTrue = "true";

      document.querySelector("[name = pwChkImg]").src = "img/safe.png";

      console.log(pwChkTrue);
    } else if (pwChkValueBox.value != pwValueBox.value) {
      const pwChkWarningBox = document.querySelector("[name=pwChkWarningBox]");
      pwChkWarningBox.style.display = "block";
      pwChkWarningBox.textContent = "비밀번호가 일치하지 않습니다.";

      document.querySelector("[name = pwChkImg]").src = "img/warning.png";

      pwChkTrue = "false";
    }
  });

  const nameCheck = /^[가-힣a-zA-Z]+$/;

  const nameValueBox = document.querySelector("[name = nameBox] > input");
  nameValueBox.addEventListener("focus", () => {
    document.querySelector("[name = nameBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  nameValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = nameBox]").style.border =
      "1px solid #dad8d8";

    if (nameValueBox.value == "") {
      const nameWarningBox = document.querySelector("[name=nameWarningBox]"); //이름검증
      nameWarningBox.style.display = "block";
      nameWarningBox.textContent = "필수 정보 입니다";

      nameTrue = "false";
    } else if (nameCheck.test(nameValueBox.value) == false) {
      const nameWarningBox = document.querySelector("[name=nameWarningBox]");
      nameWarningBox.style.display = "block";
      nameWarningBox.textContent =
        "한글과 영문 대 소문자를 사용하세요. (특수기호, 공백 사용 불가)";

      nameTrue = "false";
    }
    if (nameCheck.test(nameValueBox.value) == true) {
      const nameWarningBox = document.querySelector("[name=nameWarningBox]");
      nameWarningBox.style.display = "none";
      nameTrue = "true";

      console.log(nameTrue);
    }
  });

  const emailCheck = /^[a-zA-Z0-9+-\_.]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

  const emailValueBox = document.querySelector("[name = emailBox] > input"); //이메일 검증
  emailValueBox.addEventListener("focus", () => {
    document.querySelector("[name = emailBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  emailValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = emailBox]").style.border =
      "1px solid #dad8d8";

    if (emailValueBox.value == "") {
      const emailWarningBox = document.querySelector("[name=emailWarningBox]");
      emailWarningBox.style.display = "none";
    } else if (emailCheck.test(emailValueBox.value) != false) {
      const emailWarningBox = document.querySelector("[name=emailWarningBox]");
      emailWarningBox.style.display = "none";
    }
    if (
      emailCheck.test(emailValueBox.value) == false &&
      emailValueBox.value != ""
    ) {
      const emailWarningBox = document.querySelector("[name=emailWarningBox]");
      emailWarningBox.style.display = "block";
      emailWarningBox.textContent = "이메일 주소를 다시 확인해주세요.";
    }
  });

  const yearValueBox = document.querySelector("[name = yearBox]");
  yearValueBox.addEventListener("focus", () => {
    yearValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  yearValueBox.addEventListener("focusout", () => {
    yearValueBox.style.border = "1px solid #dad8d8";

    yearCheck = /^[0-9]{4}$/;

    if (
      yearValueBox.value == "" ||
      yearCheck.test(yearValueBox.value) == false
    ) {
      //연도검증
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      dayWarningBox.style.display = "block";
      dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";

      yearTrue = "false";
    } else if (yearCheck.test(yearValueBox.value) == true) {
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      dayWarningBox.style.display = "block";
      dayWarningBox.textContent = "태어난 월을 선택하세요.";

      yearTrue = "true";

      console.log(yearTrue);
    }
  });

  const mouthValueBox = document.querySelector("[name = mouthBox]"); //월 선택
  mouthValueBox.addEventListener("focus", () => {
    mouthValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  mouthValueBox.addEventListener("focusout", () => {
    mouthValueBox.style.border = "1px solid #dad8d8";

    if (mouthValueBox.value != "check") {
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      dayWarningBox.style.display = "block";

      if (yearTrue == "true") {
        dayWarningBox.textContent =
          "태어난 일(날짜) 2자리를 정확하게 입력하세요.";
        mouthTrue = "true";
      } else if (yearTrue != "true") {
        dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
        mouthTrue = "true";
      }

      console.log(mouthTrue);
    } else if (mouthValueBox.value == "check") {
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      dayWarningBox.style.display = "block";
      if (yearTrue == "true") {
        dayWarningBox.textContent = "태어난 월을 선택하세요.";
      } else if (yearTrue != "true") {
        dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
      }
      mouthTrue = "false";
    }
  });

  const dayValueBox = document.querySelector("[name = dayBox]"); //일 검증
  dayValueBox.addEventListener("focus", () => {
    dayValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  dayValueBox.addEventListener("focusout", () => {
    dayValueBox.style.border = "1px solid #dad8d8";

    dayCheck = /[0-9]{1,2}$/;

    const dayWarningBox = document.querySelector("[name=dayWarningBox]");

    if (dayCheck.test(dayValueBox.value) == true) {
      dayTrue = "true";
      console.log(dayTrue);

      if (yearTrue != "true") {
        dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
      } else if (yearTrue == "true" && mouthTrue != "true") {
        dayWarningBox.textContent = "태어난 월을 선택하세요.";
      } else if (yearTrue == "true" && mouthTrue == "true") {
        dayWarningBox.style.display = "none";
      }


    } else if (dayCheck.test(dayValueBox.value) != true) {
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      if (yearTrue != "true") {
        dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
      } else if (yearTrue == "true" && mouthTrue != "ture") {
        dayWarningBox.textContent = "태어난 월을 선택하세요.";
      } else if (yearTrue == "true" && mouthTrue == "ture") {
        dayWarningBox.textContent =
          "태어난 일(날짜) 2자리를 정확하게 입력하세요.";
      }
    }

    if (dayValueBox.value == "") {
      const dayWarningBox = document.querySelector("[name=dayWarningBox]");
      dayWarningBox.style.display = "block";
      dayTrue = "false";

      if (yearTrue != "true") {
        dayWarningBox.textContent = "태어난 년도 4자리를 정확하게 입력하세요.";
      } else if (yearTrue == "true" && mouthTrue != "ture") {
        dayWarningBox.textContent = "태어난 월을 선택하세요.";
      } else if (yearTrue == "true" && mouthTrue == "ture") {
        dayWarningBox.textContent =
          "태어난 일(날짜) 2자리를 정확하게 입력하세요.";
      }
    }
  });

  const genderValueBox = document.querySelector("[name = genderBox]"); //성별 포커스 스타일
  genderValueBox.addEventListener("focus", () => {
    genderValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });
  genderValueBox.addEventListener("focusout", () => {
    //성별 선택
    genderValueBox.style.border = "1px solid #dad8d8";

    if (genderValueBox.value == "check") {
      const genderWarningBox = document.querySelector(
        "[name=genderWarningBox]"
      );
      genderWarningBox.style.display = "block";
      genderWarningBox.textContent = "필수 정보 입니다";
    } else if (genderValueBox.value != "check") {
      const genderWarningBox = document.querySelector(
        "[name=genderWarningBox]"
      );
      genderWarningBox.style.display = "none";
      genderTrue = "true";

      console.log(genderTrue);
    }
  });

  const countryValueBox = document.querySelector("[name = countryBox]"); //휴대전화 국적선택
  countryValueBox.addEventListener("focus", () => {
    countryValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });

  countryValueBox.addEventListener("focusout", () => {
    countryValueBox.style.border = "1px solid #dad8d8";
  });

  const phoneValueBox = document.querySelector("[name = phoneBox]"); //휴대전화 번호 검증

  phoneValueBox.addEventListener("focus", () => {
    phoneValueBox.style.border = "1px solid rgb(55, 187, 88)";
  });

  phoneValueBox.addEventListener("focusout", () => {
    phoneValueBox.style.border = "1px solid #dad8d8";

    if (phoneValueBox.value == "") {
      const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
      phoneWarningBox.style.display = "block";
      phoneWarningBox.textContent = "필수 정보 입니다";
    } else if (phoneValueBox.value != "") {
      const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
      phoneWarningBox.style.display = "none";
    }
  });

  const safeValueBox = document.querySelector("[name = safeBox] > input"); //인증번호
  safeValueBox.addEventListener("focus", () => {
    document.querySelector("[name = safeBox]").style.border =
      "1px solid rgb(55, 187, 88)";
  });
  safeValueBox.addEventListener("focusout", () => {
    document.querySelector("[name = safeBox]").style.border =
      "1px solid #dad8d8";
  });
};

function sand() {
  const phoneCheck = /^\d{3}-?\d{3,4}-?\d{4}$/;
  const noneBox = document.querySelector("#noneBox");
  const phoneCertBox = document.querySelector("#phoneCertBox");
  const phoneValueBox = document.querySelector(".phoneBox");

  if (phoneCheck.test(phoneValueBox.value) == false) {
    const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
    phoneWarningBox.style.display = "block";
    phoneWarningBox.textContent = "형식에 맞지 않는 번호입니다.";
    phoneWarningBox.style.height = "5px";
    phoneWarningBox.style.color = "red";
  } else if (phoneCheck.test(phoneValueBox.value) == true) {
    noneBox.style.display = "none";
    phoneCertBox.style.display = "block";

    const phoneWarningBox = document.querySelector("[name=phoneWarningBox]");
    phoneWarningBox.style.display = "block";
    phoneWarningBox.style.color = "green";
    phoneWarningBox.style.height = "35px";
    phoneWarningBox.innerHTML =
      "인증번호를 발송했습니다.(유효시간 30분) <br>\
    인증번호가 오지 않으면 입력하신 정보가 정확한지 확인하여 주세요.   <br>\
    이미 가입된 번호이거나, 가상전화번호는 인증번호를 받을 수 없습니다.";
    phoneTrue = "true";

    console.log(phoneTrue);
  }
}

function nextPage() {
  if (
    idTrue == "true" &&
    pwTrue == "true" &&
    pwChkTrue == "true" &&
    nameTrue == "true" &&
    yearTrue == "true" &&
    mouthTrue == "true" &&
    dayTrue == "true" &&
    genderTrue == "true" &&
    phoneTrue == "true"
  ) {
    location.assign("complete.html");
  } else {
    alert("필수항목을 확인해주세요.");
  }
}
